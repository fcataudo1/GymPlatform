package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Operazione10 extends JFrame {

	
	private static final long serialVersionUID = 1L;
    private MenùOp menuOp; // Riferimento a MenùOp
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione10(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Eliminazione Attrezzatura in Manutenzione");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 1));

        JButton deleteButton = new JButton("Elimina Attrezzatura in Manutenzione");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eseguiEliminazioneAttrezzatura();
            }
        });

        panel.add(deleteButton);

        add(panel);
        setVisible(true);
    }

    private void eseguiEliminazioneAttrezzatura() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String deleteQuery = "DELETE FROM attrezzatura WHERE stato = 'in manutenzione'";

            try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                int righeEliminate = preparedStatement.executeUpdate();

                // Aggiorna l'outputArea di MenùOp
                menuOp.aggiornaOutputArea("\n Eliminate " + righeEliminate + " righe con lo stato 'in manutenzione'");
                dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(Operazione10.this, "Errore durante l'eliminazione: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione10 operazione10 = new Operazione10(menuOp);
            operazione10.setVisible(true);
        });
    }
}

