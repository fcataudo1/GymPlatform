package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {
    public static void main(String args[]) {
        String url = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
        String user = "GymPlatform";
        String password = "GymPlatform";

        try (Connection con = DriverManager.getConnection(url, user, password)) {
            System.out.println("Connessione riuscita \n");
        } catch (SQLException e) {
            System.out.println("Connessione fallita \n");
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
