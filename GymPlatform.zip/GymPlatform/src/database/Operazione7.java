package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class Operazione7 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private JTextField idProgrammaField, pianoAlimentareField, obiettivoProgrammaField;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione7(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Inserimento Programma Nutrizionale");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));

        JLabel idProgrammaLabel = new JLabel("ID Programma Nutrizionale:");
        idProgrammaField = new JTextField();
        JLabel pianoAlimentareLabel = new JLabel("Piano Alimentare:");
        pianoAlimentareField = new JTextField();
        JLabel obiettivoProgrammaLabel = new JLabel("Obiettivo Programma:");
        obiettivoProgrammaField = new JTextField();

        panel.add(idProgrammaLabel);
        panel.add(idProgrammaField);
        panel.add(pianoAlimentareLabel);
        panel.add(pianoAlimentareField);
        panel.add(obiettivoProgrammaLabel);
        panel.add(obiettivoProgrammaField);

        JButton insertButton = new JButton("Inserisci Programma Nutrizionale");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eseguiInserimentoProgrammaNutrizionale();
            }
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    private void eseguiInserimentoProgrammaNutrizionale() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            int idProgramma = Integer.parseInt(idProgrammaField.getText());
            String pianoAlimentare = pianoAlimentareField.getText();
            String obiettivoProgramma = obiettivoProgrammaField.getText();

            String query = "INSERT INTO programmanutrizionale (id, pianoali, obiettivo) VALUES (?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, idProgramma);
                preparedStatement.setString(2, pianoAlimentare);
                preparedStatement.setString(3, obiettivoProgramma);

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Inserimento eseguito con successo.");
                    // Dopo l'inserimento, esegui la select e visualizza i programmi nutrizionali
                    executeSelectAndDisplayProgrammiNutrizionali();
                    // Aggiorna anche l'outputArea di MenùOp
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Nessun record inserito.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Metodo per eseguire la select e visualizzare i programmi nutrizionali
    private void executeSelectAndDisplayProgrammiNutrizionali() {
        String selectQuery = "SELECT * FROM programmanutrizionale";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = statement.executeQuery()) {

            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Programmi Nutrizionali -----\n");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String pianoAlimentare = resultSet.getString("pianoali");
                String obiettivoProgramma = resultSet.getString("obiettivo");

                outputBuilder.append("ID: ").append(id).append(", Piano Alimentare: ").append(pianoAlimentare)
                        .append(", Obiettivo: ").append(obiettivoProgramma).append("\n");
            }

           
            menuOp.aggiornaOutputArea(outputBuilder.toString());
            

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errore durante la selezione: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione7 operazione7 = new Operazione7(menuOp);
            operazione7.setVisible(true);
        });
    }
}

