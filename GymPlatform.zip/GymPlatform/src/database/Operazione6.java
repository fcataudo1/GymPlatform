

package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class Operazione6 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private JTextField idAbbonamentoField, tipoAbbonamentoField, tariffaAbbonamentoField, usernameClienteField;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione6(MenùOp menuOp) {
        this.menuOp = menuOp;
        setTitle("Inserimento Abbonamento");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));

        JLabel idAbbonamentoLabel = new JLabel("ID Abbonamento:");
        idAbbonamentoField = new JTextField();
        JLabel tipoAbbonamentoLabel = new JLabel("Tipo Abbonamento:");
        tipoAbbonamentoField = new JTextField();
        JLabel tariffaAbbonamentoLabel = new JLabel("Tariffa Abbonamento:");
        tariffaAbbonamentoField = new JTextField();
        JLabel usernameClienteLabel = new JLabel("Username Cliente:");
        usernameClienteField = new JTextField();

        panel.add(idAbbonamentoLabel);
        panel.add(idAbbonamentoField);
        panel.add(tipoAbbonamentoLabel);
        panel.add(tipoAbbonamentoField);
        panel.add(tariffaAbbonamentoLabel);
        panel.add(tariffaAbbonamentoField);
        panel.add(usernameClienteLabel);
        panel.add(usernameClienteField);

        JButton insertButton = new JButton("Inserisci Abbonamento");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eseguiInserimentoAbbonamento();
            }
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    private void eseguiInserimentoAbbonamento() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            int idAbbonamento = Integer.parseInt(idAbbonamentoField.getText());
            String tipoAbbonamento = tipoAbbonamentoField.getText();
            double tariffaAbbonamento = Double.parseDouble(tariffaAbbonamentoField.getText());
            String usernameCliente = usernameClienteField.getText();

            String insertQuery = "INSERT INTO abbonamento (id, tipo, tariffa, usernamecliente) VALUES (?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setInt(1, idAbbonamento);
                preparedStatement.setString(2, tipoAbbonamento);
                preparedStatement.setDouble(3, tariffaAbbonamento);
                preparedStatement.setString(4, usernameCliente);

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Inserimento eseguito con successo.");
                    // Dopo l'inserimento, esegui la select e aggiorna l'outputArea
                    executeSelectAndDisplayAbbonamenti();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Nessun record inserito.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Metodo per eseguire la select e aggiornare l'outputArea di MenùOp
    private void executeSelectAndDisplayAbbonamenti() {
        // Esegui la select
        String selectQuery = "SELECT * FROM abbonamento";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = statement.executeQuery()) {

            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Abbonamenti -----\n");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String tipo = resultSet.getString("tipo");
                double tariffa = resultSet.getDouble("tariffa");
                String usernameCliente = resultSet.getString("usernamecliente");

                outputBuilder.append("ID: ").append(id).append(", Tipo: ").append(tipo)
                             .append(", Tariffa: ").append(tariffa).append(", Username Cliente: ").append(usernameCliente)
                             .append("\n");
            }

            // Aggiorna l'outputArea di MenùOp
            menuOp.aggiornaOutputArea(outputBuilder.toString());
            

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione6 operazione6 = new Operazione6(menuOp);
            operazione6.setVisible(true);
        });
    }
}
