package database;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Operazione17 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private JTextField usernameField, codiceSerieField;
    private MenùOp menuOp; // Riferimento a MenùOp

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione17(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Inserimento Utilizzo Attrezzatura");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("Username Cliente:");
        usernameField = new JTextField();
        JLabel codiceSerieLabel = new JLabel("Codice Serie Attrezzatura:");
        codiceSerieField = new JTextField();

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(codiceSerieLabel);
        panel.add(codiceSerieField);

        JButton insertButton = new JButton("Inserisci Utilizzo");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    executeQuery(connection);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Operazione17.this, "Errore durante la connessione al database: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(insertButton);
        add(panel);
        setVisible(true);
    }

    public void executeQuery(Connection connection) {
        String usernameCliente = usernameField.getText();
        String codiceSerieAttrezzatura = codiceSerieField.getText();

        // Query di inserimento con PreparedStatement
        String sql = "INSERT INTO utilizza (usernamecliente, codiceserieattrezzatura) VALUES (?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Imposta i parametri della query con i valori forniti dall'utente
            preparedStatement.setString(1, usernameCliente);
            preparedStatement.setString(2, codiceSerieAttrezzatura);

            // Esegue l'inserimento
            int risultato = preparedStatement.executeUpdate();

            if (risultato > 0) {
                JOptionPane.showMessageDialog(null, "Inserimento riuscito.", "Successo", JOptionPane.INFORMATION_MESSAGE);
                // Aggiorna l'output area di MenùOp
                menuOp.aggiornaOutputArea("\n Inserimento Utilizzo Attrezzatura: Username Cliente: " + usernameCliente + ", Codice Serie Attrezzatura:  " + codiceSerieAttrezzatura + "\n");
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "L'inserimento non è riuscito.", "Errore", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + e.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione17 operazione17 = new Operazione17(menuOp);
            operazione17.setVisible(true);
        });
    }
}
