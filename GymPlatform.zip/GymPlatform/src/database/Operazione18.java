package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Operazione18 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione18(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Ricerca Messaggi in Chat");
        setSize(600, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 1));

        JButton searchButton = new JButton("Visualizzare tutti i messaggi che hanno come argomento allenamento ordinati per minuti di invio");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    executeQuery(connection);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Operazione18.this, "Errore durante la connessione al database: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(searchButton);
        add(panel);
        setVisible(true);
    }

    private void executeQuery(Connection connection) {
        String sql = "SELECT * FROM messaggioinchat WHERE argomento = 'allenamento' ORDER BY orarioinvio";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                StringBuilder result = new StringBuilder();
                while (resultSet.next()) {
                    String contenutoMessaggio = resultSet.getString("contenuto");
                    String orarioInvio = resultSet.getString("orarioinvio");
                    result.append("Messaggio: ").append(contenutoMessaggio).append(", Orario Invio: ").append(orarioInvio).append("\n");
                }
                if (result.length() > 0) {
                    // Chiamata al metodo aggiornaOutputArea() del MenùOp
                    menuOp.aggiornaOutputArea(result.toString());
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + e.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione18 operazione18 = new Operazione18(menuOp);
            operazione18.setVisible(true);
        });
    }
}

