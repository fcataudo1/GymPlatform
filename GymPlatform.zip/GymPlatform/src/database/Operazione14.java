package database;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Operazione14 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione14(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Ricerca Attrezzatura per Altezza Cliente");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel heightLabel = new JLabel("Inserisci l'altezza del cliente:");
        JTextField heightField = new JTextField();
        JButton searchButton = new JButton("Selezionare nome e tipo di tutte le attrezzature utilizzate da almeno un cliente di un determinata altezza");

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executeQuery(heightField.getText());
            }
        });

        panel.add(heightLabel);
        panel.add(heightField);
        panel.add(searchButton);

        add(panel);
        setVisible(true);
    }

    private void executeQuery(String height) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "SELECT a.nome, a.tipo FROM attrezzatura a " +
                    "WHERE a.codiceserie IN (" +
                    "  SELECT u.codiceserieAttrezzatura " +
                    "  FROM utilizza u " +
                    "  WHERE u.usernamecliente IN (" +
                    "    SELECT c.username " +
                    "    FROM cliente c " +
                    "    WHERE c.altezza = ?" +
                    "  )" +
                    ")";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, height);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    StringBuilder result = new StringBuilder();
                    while (resultSet.next()) {
                        String nomeAttrezzatura = resultSet.getString("nome");
                        String tipoAttrezzatura = resultSet.getString("tipo");

                        result.append("Nome: ").append(nomeAttrezzatura).append(", Tipo: ").append(tipoAttrezzatura).append("\n");
                    }
                    if (result.length() > 0) {
                        
                        // Chiamata al metodo aggiornaOutputArea() del MenùOp
                        menuOp.aggiornaOutputArea(result.toString());
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione14 operazione14 = new Operazione14(menuOp);
            operazione14.setVisible(true);
        });
    }
}
