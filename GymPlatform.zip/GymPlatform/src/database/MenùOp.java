package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MenùOp extends JFrame {
	
	private static final long serialVersionUID = 1L;
	

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

   
    private JTextArea outputArea; // Dichiarazione dell'outputArea come variabile di istanza

    public MenùOp() {
    
    	
  
        setTitle("Gym Platform");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Menù Operazioni", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Rockwell Condensed", Font.BOLD, 24));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel operationPanel = new JPanel();
        operationPanel.setLayout(new BoxLayout(operationPanel, BoxLayout.Y_AXIS));

        JButton[] buttons = new JButton[19];
        for (int i = 1; i < 19; i++) {
        	if (i == 18) { // Aggiungi il pulsante "Esci" per l'indice 18
                buttons[i] = new JButton("Esci");
        	} else {
                buttons[i] = new JButton("Operazione " + (i + 1));
            }
            
            buttons[i].setActionCommand(String.valueOf(i + 1));
            buttons[i].addActionListener(new ButtonClickListener());
            operationPanel.add(buttons[i]);
        }

        panel.add(operationPanel, BorderLayout.WEST);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);
        setVisible(true);
    }
    
    

    // Metodo per aggiornare l'outputArea con i dati provenienti dall'operazione 2
    public void aggiornaOutputArea(String testo) {
        outputArea.append(testo);
    }

    class ButtonClickListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            int scelta = Integer.parseInt(command);

            try (Connection connessione = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("Operazione eseguita: " + scelta);

                switch (scelta) {
                    case 2:
                        Operazione2 op2 = new Operazione2(MenùOp.this);
                        op2.setVisible(true);
                        break;
                    case 3:
                        Operazione3 op3 = new Operazione3(MenùOp.this);
                        op3.setVisible(true);
                        break;
                    case 4:
                        Operazione4 op4 = new Operazione4(MenùOp.this);
                        op4.setVisible(true);
                        break;
                    case 5:
                        Operazione5 op5 = new Operazione5(MenùOp.this);
                        op5.setVisible(true);
                        break;
                    case 6:
                        Operazione6 op6 = new Operazione6(MenùOp.this);
                        op6.setVisible(true);
                        break;
                    case 7:
                        Operazione7 op7 = new Operazione7(MenùOp.this);
                        op7.setVisible(true);
                        break;
                    case 8:
                        Operazione8 op8 = new Operazione8(MenùOp.this);
                        op8.setVisible(true);
                        break;
                    case 9:
                        Operazione9 op9 = new Operazione9(MenùOp.this);
                        op9.setVisible(true);
                        break;
                    case 10:
                        Operazione10 op10 = new Operazione10(MenùOp.this);
                        op10.setVisible(true);
                        break;
                    case 11:
                        Operazione11 op11 = new Operazione11(MenùOp.this);
                        op11.setVisible(true);
                        break;
                    case 12:
                        Operazione12 op12 = new Operazione12(MenùOp.this);
                        op12.setVisible(true);
                        break;
                    case 13:
                        Operazione13 op13 = new Operazione13(MenùOp.this);
                        op13.setVisible(true);
                        break;
                    case 14:
                        Operazione14 op14 = new Operazione14(MenùOp.this);
                        op14.setVisible(true);
                        break;
                    case 15:
                        Operazione15 op15 = new Operazione15(MenùOp.this);
                        op15.setVisible(true);
                        break;
                    case 16:
                        Operazione16 op16 = new Operazione16(MenùOp.this);
                        op16.setVisible(true);
                        break;
                    case 17:
                        Operazione17 op17 = new Operazione17(MenùOp.this);
                        op17.setVisible(true);
                        break;
                    case 18:
                        Operazione18 op18 = new Operazione18(MenùOp.this);
                        op18.setVisible(true);
                        break;
                    case 19:
                        // Esci
                    	 JOptionPane.showMessageDialog(MenùOp.this, "Hai scelto di uscire. Arrivederci!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Scelta non valida.");
            } 
            }catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(MenùOp.this, "Errore durante l'operazione: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
            }
        }
    


        
    }

    public static void main(String[] args) {
    	
        SwingUtilities.invokeLater(() -> new MenùOp());
    }
}
