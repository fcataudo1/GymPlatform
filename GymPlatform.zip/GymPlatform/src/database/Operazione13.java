package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Operazione13 extends JFrame {

	
	private static final long serialVersionUID = 1L;
	
    private MenùOp menuOp; // Riferimento a MenùOp
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione13(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Ricerca Messaggio in Chat");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel searchLabel = new JLabel("Inserisci il contenuto da cercare:");
        JTextField searchField = new JTextField();
        JButton searchButton = new JButton("Selezionare i messaggi che contengono una data parola");

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executeQuery(searchField.getText());
            }
        });

        panel.add(searchLabel);
        panel.add(searchField);
        panel.add(searchButton);

        add(panel);
        setVisible(true);
    }

    private void executeQuery(String searchContent) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "SELECT m.contenuto, m.username FROM messaggioinchat m WHERE m.contenuto LIKE ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, "%" + searchContent + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    StringBuilder result = new StringBuilder();
                    while (resultSet.next()) {
                        String contenuto = resultSet.getString("contenuto");
                        String username = resultSet.getString("username");
                        result.append("Contenuto: ").append(contenuto).append(", Username: ").append(username).append("\n");
                    }
                    if (result.length() > 0) {
                        
                        menuOp.aggiornaOutputArea(result.toString());
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione13 operazione13 = new Operazione13(menuOp);
            operazione13.setVisible(true);
        });
    }
}
