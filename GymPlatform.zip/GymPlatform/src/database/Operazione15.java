package database;

import javax.swing.*;
import java.awt.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Operazione15 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione15(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Ricerca Username Istruttore");
        setSize(450, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 1));

        JLabel infoLabel = new JLabel("Seleziona il nome degli istruttori che tengono almeno 1 corso");
        JButton searchButton = new JButton("Cerca");

        searchButton.addActionListener(e -> {
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                executeQuery(connection);
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Errore durante la connessione al database: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(infoLabel);
        panel.add(searchButton);

        add(panel);
        setVisible(true);
    }

    private void executeQuery(Connection connection) {
        String sql = "SELECT i.username FROM istruttore i WHERE i.username IN (SELECT c.usernameistruttore FROM corso c)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                StringBuilder result = new StringBuilder();
                while (resultSet.next()) {
                    String usernameIstruttore = resultSet.getString("username");
                    result.append("Username Istruttore: ").append(usernameIstruttore).append("\n");
                }
                if (result.length() > 0) {
                    
                    // Chiamata al metodo aggiornaOutputArea() del MenùOp
                    menuOp.aggiornaOutputArea(result.toString());
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione15 operazione15 = new Operazione15(menuOp);
            operazione15.setVisible(true);
        });
    }
}
