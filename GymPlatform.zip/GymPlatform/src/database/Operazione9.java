package database;


import javax.swing.*;

import java.awt.GridLayout;
import java.sql.*;

public class Operazione9 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione9(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Query Somma Tariffe Totali");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton queryButton = new JButton("Selezionare quanto hanno speso in abbonamenti i clienti");
        queryButton.addActionListener(e -> {
            eseguiQuerySommaTariffe();
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 1));
        panel.add(queryButton);
        add(panel);

        setVisible(true);
    }

    private void eseguiQuerySommaTariffe() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT SUM(a.tariffa) as TariffeTot " +
                    "FROM cliente as c, abbonamento as a " +
                    "WHERE c.username=a.usernamecliente";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                if (resultSet.next()) {
                    double tariffeTot = resultSet.getDouble("TariffeTot");
                    String resultText = "\n La somma delle tariffe totali è: " + tariffeTot;
                    // Chiamata al metodo aggiornaOutputArea() di MenùOp
                    menuOp.aggiornaOutputArea(resultText);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(Operazione9.this, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(Operazione9.this, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione9 operazione9 = new Operazione9(menuOp);
            operazione9.setVisible(true);
        });
    }
}
