package database;


import javax.swing.*;
import javax.swing.JFrame;

import java.awt.event.*;
import java.sql.*;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JCheckBox;

public class LoginPage extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;
    private JTextField usernameField, nomeField, cognomeField, telefonoField, genereField, dataNascitaField, indirizzoField, emailField;
    private JPasswordField passwordField;
    private JButton confirmLoginButton;
    private JButton loginButton, registerButton, confirmRegistrationButton;
    private JPanel panel;
    private JCheckBox istruttoreCheckBox;
    private JCheckBox clienteCheckBox;
    
    

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";
    
    

    public LoginPage() {
    	
        setTitle("Login Page");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Layout verticale
        panel.setAlignmentX(Component.CENTER_ALIGNMENT); // Allineamento al centro orizzontale

        // Aggiunta del JLabel per il titolo centrato
        JLabel titleLabel = new JLabel("GYM PLATFORM");
        titleLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 60));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createVerticalGlue()); // Spazio vuoto sopra
        panel.add(titleLabel);
        panel.add(Box.createVerticalGlue()); // Spazio vuoto sotto il titolo

        loginButton = new JButton("      LOGIN      ");
        loginButton.setPreferredSize(new Dimension(200, 50)); // Imposta la dimensione del pulsante login
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Allineamento al centro orizzontale
        loginButton.addActionListener(this);

        registerButton = new JButton("REGISTRAZIONE");
        registerButton.setPreferredSize(new Dimension(200, 50)); // Imposta la dimensione del pulsante di registrazione
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Allineamento al centro orizzontale
        registerButton.addActionListener(this);
        
        // Aggiunta dei pulsanti al pannello
        panel.add(loginButton);
        panel.add(Box.createVerticalStrut(10)); // Spaziatura verticale
        panel.add(registerButton);

        // Aggiunta del pannello alla finestra
        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }
    


    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == loginButton) {
            // Nascondi i campi di login esistenti
            panel.remove(loginButton);
            panel.remove(registerButton);

            // Aggiungi i campi per l'email e la password
            JLabel emailLabel = new JLabel("Email:");
            emailField = new JTextField(20);
            JLabel passwordLabel = new JLabel("Password:");
            passwordField = new JPasswordField(20);

            // Create a panel for holding the email and password fields
            JPanel fieldsPanel = new JPanel(new GridLayout(2, 2)); // Grid layout for email and password labels and fields
            fieldsPanel.add(emailLabel);
            fieldsPanel.add(emailField);
            fieldsPanel.add(passwordLabel);
            fieldsPanel.add(passwordField);

            // Aggiungi il pannello dei campi email e password al pannello principale
            panel.add(fieldsPanel);

            // Aggiungi un nuovo pulsante per confermare il login
            confirmLoginButton = new JButton("Log In");
            confirmLoginButton.addActionListener(this);

            // Create a panel for holding the confirm login button
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // FlowLayout centered
            buttonPanel.add(confirmLoginButton);

            // Aggiungi il pannello del pulsante di conferma al pannello principale
            panel.add(buttonPanel);

            // Aggiorna il layout
            panel.revalidate();
            panel.repaint();
        } else if (ae.getSource() == confirmLoginButton) {
            // Implementa la logica per il controllo del login con email e password
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            boolean loggedIn = checkLogin(email, password);
            if (loggedIn) {
                JOptionPane.showMessageDialog(this, "Login eseguito con successo!");
             	
                    // Mostra la finestra di MainApp
                    MenùOp mainApp = new MenùOp();
                    
                    mainApp.setVisible(true);
                    dispose(); // Chiudi la finestra di login
                    
                
            } else {
                JOptionPane.showMessageDialog(this, "Credenziali non valide. Riprova.");
            }
        } else if (ae.getSource() == registerButton) {
            // Nascondi i campi di login esistenti
            panel.remove(loginButton);
            panel.remove(registerButton);

            // Aggiungi i campi per la registrazione
            JLabel usernameLabel = new JLabel("Username:");
            usernameField = new JTextField(20);
            JLabel passwordLabel = new JLabel("Password:");
            passwordField = new JPasswordField(20);
            JLabel nomeLabel = new JLabel("Nome:");
            nomeField = new JTextField(20);
            JLabel cognomeLabel = new JLabel("Cognome:");
            cognomeField = new JTextField(20);
            JLabel telefonoLabel = new JLabel("Telefono:");
            telefonoField = new JTextField(20);
            JLabel genereLabel = new JLabel("Genere:");
            genereField = new JTextField(20);
            JLabel dataNascitaLabel = new JLabel("Data di Nascita:");
            dataNascitaField = new JTextField(20);
            JLabel indirizzoLabel = new JLabel("Indirizzo:");
            indirizzoField = new JTextField(20);
            JLabel emailLabel = new JLabel("Email:");
            emailField = new JTextField(20);

            // Create a panel for holding the registration fields
            JPanel fieldsPanel = new JPanel(new GridLayout(5, 2)); // Grid layout for registration fields

            fieldsPanel.add(usernameLabel);
            fieldsPanel.add(usernameField);
            fieldsPanel.add(passwordLabel);
            fieldsPanel.add(passwordField);
            fieldsPanel.add(nomeLabel);
            fieldsPanel.add(nomeField);
            fieldsPanel.add(cognomeLabel);
            fieldsPanel.add(cognomeField);
            fieldsPanel.add(telefonoLabel);
            fieldsPanel.add(telefonoField);
            fieldsPanel.add(genereLabel);
            fieldsPanel.add(genereField);
            fieldsPanel.add(dataNascitaLabel);
            fieldsPanel.add(dataNascitaField);
            fieldsPanel.add(indirizzoLabel);
            fieldsPanel.add(indirizzoField);
            fieldsPanel.add(emailLabel);
            fieldsPanel.add(emailField);
            // Add other registration fields...

            istruttoreCheckBox = new JCheckBox("Istruttore");
            clienteCheckBox = new JCheckBox("Cliente");

            // Aggiungi il pannello dei campi di registrazione al pannello principale
            panel.add(fieldsPanel);

            // Aggiungi il pannello dei checkbox al pannello principale
            JPanel checkBoxPanel = new JPanel(new GridLayout(1, 2));
            checkBoxPanel.add(istruttoreCheckBox);
            checkBoxPanel.add(clienteCheckBox);
            panel.add(checkBoxPanel);

            // Aggiungi il pulsante di conferma registrazione
            confirmRegistrationButton = new JButton("Conferma registrazione");
            confirmRegistrationButton.addActionListener(this);
            panel.add(confirmRegistrationButton);

            // Aggiorna il layout
            panel.revalidate();
            panel.repaint();
        } else if (ae.getSource() == confirmRegistrationButton) {
            // Implementa la logica per la registrazione
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String nome = nomeField.getText();
            String cognome = cognomeField.getText();
            String telefono = telefonoField.getText();
            String genere = genereField.getText();
            String dataNascita = dataNascitaField.getText();
            String indirizzo = indirizzoField.getText();
            String email = emailField.getText();

            boolean isIstruttore = istruttoreCheckBox.isSelected();
            boolean isCliente = clienteCheckBox.isSelected();

            // Verifica se almeno uno dei due è spuntato
            if (!isIstruttore && !isCliente) {
                JOptionPane.showMessageDialog(this, "Seleziona almeno una delle opzioni: Istruttore o Cliente");
                return;
            }

            boolean registered = registerUser(username, password, nome, cognome, telefono, genere, dataNascita, indirizzo, email);
            if (registered) {
               
                JOptionPane.showMessageDialog(this, "Registrazione eseguita con successo!");

                if (isIstruttore && isCliente) {
                    // Entrambi sono spuntati, quindi chiedi i dettagli sia dell'istruttore che del cliente
                    JPanel istruttorePanel = new JPanel();
                    JTextField oreLavoroField = new JTextField(10);
                    JTextField certificazioneField = new JTextField(10); // Nuovo campo per la certificazione
                    istruttorePanel.add(new JLabel("Ore Lavoro:"));
                    istruttorePanel.add(oreLavoroField);
                    istruttorePanel.add(new JLabel("Certificazione:"));
                    istruttorePanel.add(certificazioneField);

                    int result = JOptionPane.showConfirmDialog(null, istruttorePanel, "Dettagli Istruttore", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        int oreLavoro = Integer.parseInt(oreLavoroField.getText());
                        String certificazione = certificazioneField.getText(); // Ottieni il valore della certificazione
                        boolean insertedIC = registerIC(username, true, false, oreLavoro, 0, 0, 0, certificazione); // Aggiungi il parametro per la certificazione
                        if (insertedIC) {
                            JOptionPane.showMessageDialog(this, "Dettagli Istruttore inseriti con successo!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento dei dettagli dell'istruttore.");
                        }
                    }

                    // Pannello per i dettagli del cliente
                    JPanel clientePanel = new JPanel();
                    JTextField altezzaField = new JTextField(10);
                    JTextField pesoField = new JTextField(10);
                    JTextField idProgrammaNutrizionaleField = new JTextField(10);
                    clientePanel.add(new JLabel("Altezza:"));
                    clientePanel.add(altezzaField);
                    clientePanel.add(new JLabel("Peso:"));
                    clientePanel.add(pesoField);
                    clientePanel.add(new JLabel("ID Programma Nutrizionale:"));
                    clientePanel.add(idProgrammaNutrizionaleField);

                    result = JOptionPane.showConfirmDialog(null, clientePanel, "Dettagli Cliente", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        int altezza = Integer.parseInt(altezzaField.getText());
                        int peso = Integer.parseInt(pesoField.getText());
                        int idProgrammaNutrizionale = Integer.parseInt(idProgrammaNutrizionaleField.getText());
                        boolean insertedIC = registerIC(username, false, true, 0, altezza, peso, idProgrammaNutrizionale, null); // Passa null per la certificazione
                        if (insertedIC) {
                            JOptionPane.showMessageDialog(this, "Dettagli Cliente inseriti con successo!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento dei dettagli del cliente.");
                        }
                    }
                } else if (isIstruttore) {
                    // Solo l'istruttore è spuntato
                    JPanel istruttorePanel = new JPanel();
                    JTextField oreLavoroField = new JTextField(10);
                    JTextField certificazioneField = new JTextField(10); // Nuovo campo per la certificazione
                    istruttorePanel.add(new JLabel("Ore Lavoro:"));
                    istruttorePanel.add(oreLavoroField);
                    istruttorePanel.add(new JLabel("Certificazione:"));
                    istruttorePanel.add(certificazioneField);

                    int result = JOptionPane.showConfirmDialog(null, istruttorePanel, "Dettagli Istruttore", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        int oreLavoro = Integer.parseInt(oreLavoroField.getText());
                        String certificazione = certificazioneField.getText(); // Ottieni il valore della certificazione
                        boolean insertedIC = registerIC(username, true, false, oreLavoro, 0, 0, 0, certificazione); // Aggiungi il parametro per la certificazione
                        if (insertedIC) {
                            JOptionPane.showMessageDialog(this, "Dettagli Istruttore inseriti con successo!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento dei dettagli dell'istruttore.");
                        }
                    }
                } else if (isCliente) {
                    // Solo il cliente è spuntato
                    JPanel clientePanel = new JPanel();
                    JTextField altezzaField = new JTextField(10);
                    JTextField pesoField = new JTextField(10);
                    JTextField idProgrammaNutrizionaleField = new JTextField(10);
                    clientePanel.add(new JLabel("Altezza:"));
                    clientePanel.add(altezzaField);
                    clientePanel.add(new JLabel("Peso:"));
                    clientePanel.add(pesoField);
                    clientePanel.add(new JLabel("ID Programma Nutrizionale:"));
                    clientePanel.add(idProgrammaNutrizionaleField);

                    int result = JOptionPane.showConfirmDialog(null, clientePanel, "Dettagli Cliente", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        int altezza = Integer.parseInt(altezzaField.getText());
                        int peso = Integer.parseInt(pesoField.getText());
                        int idProgrammaNutrizionale = Integer.parseInt(idProgrammaNutrizionaleField.getText());
                        boolean insertedIC = registerIC(username, false, true, 0, altezza, peso, idProgrammaNutrizionale, null); // Passa null per la certificazione
                        if (insertedIC) {
                            JOptionPane.showMessageDialog(this, "Dettagli Cliente inseriti con successo!");
                            
                        } else {
                            JOptionPane.showMessageDialog(this, "Errore durante l'inserimento dei dettagli del cliente.");
                        }
                    }
                   
                }
                dispose();

                // Mostra la finestra di login
                LoginPage loginFrame = new LoginPage();
                loginFrame.setVisible(true);
                
               

    	    } else {
    	        JOptionPane.showMessageDialog(this, "Errore durante la registrazione. Riprova.");
    	    }
    	}
        
       

    }

    private boolean checkLogin(String email, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String query = "SELECT * FROM accountuser WHERE email=? AND passw=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean registerUser(String username, String password, String nome, String cognome, String telefono, String genere, String dataNascita, String indirizzo, String email) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String query = "INSERT INTO accountuser (username, nome, cognome, passw, telefono, genere, dataNascita, indirizzo, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, nome);
            statement.setString(3, cognome);
            statement.setString(4, password);
            statement.setString(5, telefono);
            statement.setString(6, genere);
            statement.setString(7, dataNascita);
            statement.setString(8, indirizzo);
            statement.setString(9, email);
            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    } 
    
    private boolean registerIC(String username, boolean isIstruttore, boolean isCliente, int orelavoro, int altezza, int peso, int idprogrammanutrizionale, String certificazione) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            
            if (isIstruttore) {
                String istruttoreQuery = "INSERT INTO istruttore (username, orelavoro, certificazione) VALUES (?, ?, ?)";
                statement = connection.prepareStatement(istruttoreQuery);
                statement.setString(1, username);
                statement.setInt(2, orelavoro);
                statement.setString(3, certificazione);
                statement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Secondo blocco try-catch-finally per la seconda operazione
        try {
            if (isCliente) {
                String clienteQuery = "INSERT INTO cliente (username, altezza, peso, idprogrammanutrizionale) VALUES (?, ?, ?, ?)";
                statement = connection.prepareStatement(clienteQuery);
                statement.setString(1, username);
                statement.setInt(2, altezza);
                statement.setInt(3, peso);
                statement.setInt(4, idprogrammanutrizionale);
                statement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return true;
    }
    
    



    public static void main(String[] args) {
        new LoginPage();
    }
}
