package database;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Operazione2 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp
    

    private JTextField codiceField, usernameField, argomentoField, orarioInvioField, contenutoField;

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione2(MenùOp menuOp) {
        this.menuOp = menuOp;
        setTitle("Inserimento Messaggio Chat");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));

        JLabel codiceLabel = new JLabel("Codice:");
        codiceField = new JTextField();
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        JLabel argomentoLabel = new JLabel("Argomento:");
        argomentoField = new JTextField();
        JLabel orarioInvioLabel = new JLabel("Orario di invio (YYYY-MM-DD HH:mm:ss):");
        orarioInvioField = new JTextField();
        JLabel contenutoLabel = new JLabel("Contenuto:");
        contenutoField = new JTextField();

        panel.add(codiceLabel);
        panel.add(codiceField);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(argomentoLabel);
        panel.add(argomentoField);
        panel.add(orarioInvioLabel);
        panel.add(orarioInvioField);
        panel.add(contenutoLabel);
        panel.add(contenutoField);

        JButton insertButton = new JButton("Inserisci Messaggio");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    int codice = Integer.parseInt(codiceField.getText());
                    String username = usernameField.getText();
                    String argomento = argomentoField.getText();
                    String orarioInvio = orarioInvioField.getText();
                    String contenuto = contenutoField.getText();

                    String insertQuery = "INSERT INTO messaggioinchat (codice, username, argomento, orarioinvio, contenuto) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                        preparedStatement.setInt(1, codice);
                        preparedStatement.setString(2, username);
                        preparedStatement.setString(3, argomento);
                        preparedStatement.setString(4, orarioInvio);
                        preparedStatement.setString(5, contenuto);

                        int rowsAffected = preparedStatement.executeUpdate();

                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(Operazione2.this, "Inserimento eseguito con successo.");
                            // Dopo l'inserimento, esegui la select e aggiorna l'outputArea
                            executeSelectAndDisplay();
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(Operazione2.this, "Nessun record inserito.");
                        }
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Operazione2.this, "Errore durante l'inserimento del messaggio: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(Operazione2.this, "Il codice deve essere un numero intero.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    // Metodo per eseguire la select e aggiornare l'outputArea in MenùOp
    private void executeSelectAndDisplay() {
        // Esegui la select
        String selectQuery = "SELECT * FROM messaggioinchat";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Messaggio in chat -----\n");
            while (resultSet.next()) {
                int codice = resultSet.getInt("codice");
                String username = resultSet.getString("username");
                String argomento = resultSet.getString("argomento");
                String orarioInvio = resultSet.getString("orarioinvio");
                String contenuto = resultSet.getString("contenuto");
                outputBuilder.append("Codice: ").append(codice).append(", Username: ").append(username)
                        .append(", Argomento: ").append(argomento).append(", Orario di invio: ")
                        .append(orarioInvio).append(", Contenuto: ").append(contenuto).append("\n");
            }
            // Aggiorna l'outputArea di MenùOp
            menuOp.aggiornaOutputArea(outputBuilder.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione2 operazione2 = new Operazione2(menuOp);
            operazione2.setVisible(true);
        });
    }

}
