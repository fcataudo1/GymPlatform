package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Operazione8 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private JTextField usernameIstruttoreField;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione8(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Query Numero Corsi per Istruttore");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));
        
        JLabel usernameIstruttoreLabel = new JLabel("Username Istruttore:");
        usernameIstruttoreField = new JTextField();

        panel.add(usernameIstruttoreLabel);
        panel.add(usernameIstruttoreField);

        JButton queryButton = new JButton("Esegui Query");
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eseguiQueryNumeroCorsi();
            }
        });

        panel.add(queryButton);

        add(panel);
        setVisible(true);
    }

    private void eseguiQueryNumeroCorsi() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String usernameIstruttore = usernameIstruttoreField.getText();

            String query = "SELECT COUNT(*) as NumCorsi " +
                           "FROM istruttore as i, corso as c " +
                           "WHERE i.username=? AND i.username=c.usernameistruttore";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, usernameIstruttore);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int numCorsi = resultSet.getInt("NumCorsi");
                        String resultText = "\n Il numero di corsi associati all'istruttore " + usernameIstruttore + " è: " + numCorsi;
                        // Chiamata al metodo aggiornaOutputArea() del MenùOp
                        menuOp.aggiornaOutputArea(resultText);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(Operazione8.this, "L'istruttore " + usernameIstruttore + " non è associato a nessun corso.", "Nessun Corso", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(Operazione8.this, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione8 operazione8 = new Operazione8(menuOp);
            operazione8.setVisible(true);
        });
    }
}

