package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Operazione3 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private JTextField codiceSchedaField, tipologiaSchedaField, usernameIstruttoreField, codiceEsercizioField, nomeEsercizioField;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    private MenùOp menuOp; // Riferimento a MenùOp

    public Operazione3(MenùOp menuOp) {
        this.menuOp = menuOp;
        setTitle("Inserimento Scheda ed Esercizio");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));

        JLabel codiceSchedaLabel = new JLabel("Codice Scheda:");
        codiceSchedaField = new JTextField();
        JLabel tipologiaSchedaLabel = new JLabel("Tipologia Scheda:");
        tipologiaSchedaField = new JTextField();
        JLabel usernameIstruttoreLabel = new JLabel("Username Istruttore:");
        usernameIstruttoreField = new JTextField();
        JLabel codiceEsercizioLabel = new JLabel("Codice Esercizio:");
        codiceEsercizioField = new JTextField();
        JLabel nomeEsercizioLabel = new JLabel("Nome Esercizio:");
        nomeEsercizioField = new JTextField();

        panel.add(codiceSchedaLabel);
        panel.add(codiceSchedaField);
        panel.add(tipologiaSchedaLabel);
        panel.add(tipologiaSchedaField);
        panel.add(usernameIstruttoreLabel);
        panel.add(usernameIstruttoreField);
        panel.add(codiceEsercizioLabel);
        panel.add(codiceEsercizioField);
        panel.add(nomeEsercizioLabel);
        panel.add(nomeEsercizioField);

        JButton insertButton = new JButton("Inserisci Scheda ed Esercizio");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    int codiceScheda = Integer.parseInt(codiceSchedaField.getText());
                    String tipologiaScheda = tipologiaSchedaField.getText();
                    String usernameIstruttore = usernameIstruttoreField.getText();
                    int codiceEsercizio = Integer.parseInt(codiceEsercizioField.getText());
                    String nomeEsercizio = nomeEsercizioField.getText();

                    String queryScheda = "INSERT INTO schedaallenamento (codice, tipologia, usernameistruttore) VALUES (?, ?, ?)";
                    try (PreparedStatement preparedStatementScheda = connection.prepareStatement(queryScheda)) {
                        preparedStatementScheda.setInt(1, codiceScheda);
                        preparedStatementScheda.setString(2, tipologiaScheda);
                        preparedStatementScheda.setString(3, usernameIstruttore);

                        int resultScheda = preparedStatementScheda.executeUpdate();

                        if (resultScheda > 0) {
                            JOptionPane.showMessageDialog(Operazione3.this, "Inserimento scheda di allenamento effettuato con successo!");
                        } else {
                            JOptionPane.showMessageDialog(Operazione3.this, "Errore durante l'inserimento della scheda di allenamento.");
                        }
                    }

                    String queryEsercizio = "INSERT INTO esercizio (codice, codiceschedaallenamento, nome) VALUES (?, ?, ?)";
                    try (PreparedStatement preparedStatementEsercizio = connection.prepareStatement(queryEsercizio)) {
                        preparedStatementEsercizio.setInt(1, codiceEsercizio);
                        preparedStatementEsercizio.setInt(2, codiceScheda);
                        preparedStatementEsercizio.setString(3, nomeEsercizio);

                        int resultEsercizio = preparedStatementEsercizio.executeUpdate();

                        if (resultEsercizio > 0) {
                            JOptionPane.showMessageDialog(Operazione3.this, "Inserimento esercizio effettuato con successo!");
                            executeSelectSchedaAndDisplay(); // Aggiorna l'outputArea di MenùOp
                            executeSelectEsercizioAndDisplay(); // Aggiorna l'outputArea di MenùOp
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(Operazione3.this, "Errore durante l'inserimento dell'esercizio.");
                        }
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Operazione3.this, "Errore durante l'inserimento: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(Operazione3.this, "I codici devono essere numeri interi.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    // Metodo per eseguire la select delle schede di allenamento e aggiornare l'outputArea in MenùOp
    private void executeSelectSchedaAndDisplay() {
        String selectQuery = "SELECT * FROM schedaallenamento";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Scheda Allenamento -----\n");
            while (resultSet.next()) {
                int codice = resultSet.getInt("codice");
                String tipologia = resultSet.getString("tipologia");
                String usernameIstruttore = resultSet.getString("usernameistruttore");
                outputBuilder.append("Codice: ").append(codice).append(", Tipologia: ").append(tipologia)
                        .append(", Username Istruttore: ").append(usernameIstruttore).append("\n");
            }
            // Aggiorna l'outputArea di MenùOp con le schede di allenamento
            menuOp.aggiornaOutputArea(outputBuilder.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Metodo per eseguire la select degli esercizi e aggiornare l'outputArea in MenùOp
    private void executeSelectEsercizioAndDisplay() {
        String selectQuery = "SELECT * FROM esercizio";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Esercizi -----\n");
            while (resultSet.next()) {
                int codice = resultSet.getInt("codice");
                int codiceSchedaAllenamento = resultSet.getInt("codiceschedaallenamento");
                String nome = resultSet.getString("nome");
                outputBuilder.append("Codice: ").append(codice)
                        .append(", Codice Scheda Allenamento: ").append(codiceSchedaAllenamento)
                        .append(", Nome: ").append(nome).append("\n");
            }
            // Aggiorna l'outputArea di MenùOp con gli esercizi
            menuOp.aggiornaOutputArea(outputBuilder.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Operazione3(null)); // Passa null in quanto non c'è riferimento a MenùOp
    }
}
