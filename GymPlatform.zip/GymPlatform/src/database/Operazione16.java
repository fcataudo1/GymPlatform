package database;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Operazione16 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione16(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Operazione 16 - Ricerca Abbonamenti Femminili");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 1));

        JButton searchButton = new JButton("Selezionare gli abbonamenti sottoscritti da clienti donne");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    executeQuery(connection);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Operazione16.this, "Errore durante la connessione al database: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(searchButton);
        add(panel);
        setVisible(true);
    }

    private void executeQuery(Connection connection) {
        String sql = "SELECT a.usernamecliente, a.id, a.tipo, a.tariffa FROM abbonamento a WHERE a.usernamecliente IN " +
                "(SELECT acc.username FROM accountuser acc WHERE acc.genere = 'Donna')";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                StringBuilder result = new StringBuilder();
                while (resultSet.next()) {
                    String usernameCliente = resultSet.getString("usernamecliente");
                    int idAbbonamento = resultSet.getInt("id");
                    String tipoAbbonamento = resultSet.getString("tipo");
                    double tariffaAbbonamento = resultSet.getDouble("tariffa");

                    result.append("Username Cliente: ").append(usernameCliente).append(", ")
                            .append("ID: ").append(idAbbonamento).append(", ")
                            .append("Tipo Abbonamento: ").append(tipoAbbonamento).append(", ")
                            .append("Tariffa Abbonamento: ").append(tariffaAbbonamento).append("\n");
                }
                if (result.length() > 0) {
                    // Chiamata al metodo aggiornaOutputArea() del MenùOp
                    menuOp.aggiornaOutputArea(result.toString());
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + e.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione16 operazione16 = new Operazione16(menuOp);
            operazione16.setVisible(true);
        });
    }
}



