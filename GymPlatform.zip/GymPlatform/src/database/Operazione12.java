package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Operazione12 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione12(MenùOp menuOp) {
        this.menuOp = menuOp; // Imposta il riferimento a MenùOp
        setTitle("Query Istruttori con più 3 ore di lavoro");
        setSize(600, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 1));

        JButton queryButton = new JButton("\n Selezionare l’username degli istruttori che hanno lavorato almeno 4 ore");
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executeQuery();
            }
        });

        panel.add(queryButton);

        add(panel);
        setVisible(true);
    }

    public void executeQuery() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "SELECT i.username FROM istruttore i WHERE i.oreLavoro > 3 ORDER BY i.username DESC";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    StringBuilder result = new StringBuilder();
                    while (resultSet.next()) {
                        // Recupera il valore della colonna 'username'
                        String username = resultSet.getString("username");
                        result.append("Username: ").append(username).append("\n");
                    }
                    if (result.length() > 0) {
                        
                        // Chiamata al metodo aggiornaOutputArea() del MenùOp
                        menuOp.aggiornaOutputArea(result.toString());
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Nessun risultato trovato.", "Risultato Vuoto", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'esecuzione della query: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione12 operazione12 = new Operazione12(menuOp);
            operazione12.setVisible(true);
        });
    }
}
