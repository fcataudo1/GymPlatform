package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;

public class Operazione4 extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private JTextField nomeCorsoField, descrizioneCorsoField, usernameIstruttoreField;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione4(MenùOp menuOp) {
        this.menuOp = menuOp;
        setTitle("Inserimento Corso");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 5));

        JLabel nomeCorsoLabel = new JLabel("Nome Corso:");
        nomeCorsoField = new JTextField();
        JLabel descrizioneCorsoLabel = new JLabel("Descrizione Corso:");
        descrizioneCorsoField = new JTextField();
        JLabel usernameIstruttoreLabel = new JLabel("Username Istruttore:");
        usernameIstruttoreField = new JTextField();

        panel.add(nomeCorsoLabel);
        panel.add(nomeCorsoField);
        panel.add(descrizioneCorsoLabel);
        panel.add(descrizioneCorsoField);
        panel.add(usernameIstruttoreLabel);
        panel.add(usernameIstruttoreField);

        JButton insertButton = new JButton("Inserisci Corso");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eseguiInserimentoCorso();
            }
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    private void eseguiInserimentoCorso() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String nomeCorso = nomeCorsoField.getText();
            String descrizioneCorso = descrizioneCorsoField.getText();
            String usernameIstruttore = usernameIstruttoreField.getText();

            String insertQuery = "INSERT INTO corso (nome, descrizione, usernameistruttore) VALUES (?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, nomeCorso);
                preparedStatement.setString(2, descrizioneCorso);
                preparedStatement.setString(3, usernameIstruttore);

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(Operazione4.this, "Inserimento eseguito con successo.");
                    // Dopo l'inserimento, esegui la select e aggiorna l'outputArea
                    executeSelectAndDisplay();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(Operazione4.this, "Nessun record inserito.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(Operazione4.this, "Errore durante l'inserimento del corso: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Metodo per eseguire la select e aggiornare l'outputArea in MenùOp
    private void executeSelectAndDisplay() {
        // Esegui la select
        String selectQuery = "SELECT * FROM corso";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("----- Corsi -----\n");
            while (resultSet.next()) {
                String nomeCorso = resultSet.getString("nome");
                String descrizioneCorso = resultSet.getString("descrizione");
                String usernameIstruttore = resultSet.getString("usernameistruttore");
                outputBuilder.append("Nome Corso: ").append(nomeCorso).append(", Descrizione: ").append(descrizioneCorso)
                        .append(", Username Istruttore: ").append(usernameIstruttore).append("\n");
            }
            // Aggiorna l'outputArea di MenùOp
            menuOp.aggiornaOutputArea(outputBuilder.toString());
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione4 operazione4 = new Operazione4(menuOp);
            operazione4.setVisible(true);
        });
    }
}
