package database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class Operazione5 extends JFrame {
	
	
	private static final long serialVersionUID = 1L;

    private MenùOp menuOp; // Riferimento a MenùOp

    private JTextField codiceSerieField, tipoAttrezzaturaField, statoAttrezzaturaField, quantitaAttrezzaturaField, nomeAttrezzaturaField, usernameClienteField;

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/GymPlatform";
    private static final String USER = "GymPlatform";
    private static final String PASSWORD = "GymPlatform";

    public Operazione5(MenùOp menuOp) {
        this.menuOp = menuOp;
        setTitle("Inserimento Attrezzatura e Utilizzo");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 5));

        JLabel codiceSerieLabel = new JLabel("Codice Serie Attrezzatura:");
        codiceSerieField = new JTextField();
        JLabel tipoAttrezzaturaLabel = new JLabel("Tipo Attrezzatura:");
        tipoAttrezzaturaField = new JTextField();
        JLabel statoAttrezzaturaLabel = new JLabel("Stato Attrezzatura:");
        statoAttrezzaturaField = new JTextField();
        JLabel quantitaAttrezzaturaLabel = new JLabel("Quantità Attrezzatura:");
        quantitaAttrezzaturaField = new JTextField();
        JLabel nomeAttrezzaturaLabel = new JLabel("Nome Attrezzatura:");
        nomeAttrezzaturaField = new JTextField();
        JLabel usernameClienteLabel = new JLabel("Username Cliente:");
        usernameClienteField = new JTextField();

        panel.add(codiceSerieLabel);
        panel.add(codiceSerieField);
        panel.add(tipoAttrezzaturaLabel);
        panel.add(tipoAttrezzaturaField);
        panel.add(statoAttrezzaturaLabel);
        panel.add(statoAttrezzaturaField);
        panel.add(quantitaAttrezzaturaLabel);
        panel.add(quantitaAttrezzaturaField);
        panel.add(nomeAttrezzaturaLabel);
        panel.add(nomeAttrezzaturaField);
        panel.add(usernameClienteLabel);
        panel.add(usernameClienteField);

        JButton insertButton = new JButton("Inserisci Attrezzatura e Utilizzo");
        insertButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
        	        int codiceSerieAttrezzatura = Integer.parseInt(codiceSerieField.getText());
        	        String tipoAttrezzatura = tipoAttrezzaturaField.getText();
        	        String statoAttrezzatura = statoAttrezzaturaField.getText();
        	        int quantitaAttrezzatura = Integer.parseInt(quantitaAttrezzaturaField.getText());
        	        String nomeAttrezzatura = nomeAttrezzaturaField.getText();
        	        String usernameCliente = usernameClienteField.getText();

        	        String queryAttrezzatura = "INSERT INTO attrezzatura (codiceserie, tipo, stato, quantità, nome) VALUES (?, ?, ?, ?, ?)";
        	        String queryUtilizzo = "INSERT INTO utilizza (usernamecliente, codiceserieattrezzatura) VALUES (?, ?)";

        	        try (PreparedStatement preparedStatementAttrezzatura = connection.prepareStatement(queryAttrezzatura);
        	             PreparedStatement preparedStatementUtilizzo = connection.prepareStatement(queryUtilizzo)) {
        	            preparedStatementAttrezzatura.setInt(1, codiceSerieAttrezzatura);
        	            preparedStatementAttrezzatura.setString(2, tipoAttrezzatura);
        	            preparedStatementAttrezzatura.setString(3, statoAttrezzatura);
        	            preparedStatementAttrezzatura.setInt(4, quantitaAttrezzatura);
        	            preparedStatementAttrezzatura.setString(5, nomeAttrezzatura);

        	            int resultAttrezzatura = preparedStatementAttrezzatura.executeUpdate();

        	            preparedStatementUtilizzo.setString(1, usernameCliente);
        	            preparedStatementUtilizzo.setInt(2, codiceSerieAttrezzatura);

        	            int resultUtilizzo = preparedStatementUtilizzo.executeUpdate();

        	            if (resultAttrezzatura > 0 && resultUtilizzo > 0) {
        	                JOptionPane.showMessageDialog(Operazione5.this, "Inserimento attrezzatura e utilizzo effettuato con successo!");
        	                // Dopo l'inserimento, esegui la select e aggiorna l'outputArea
        	                executeSelectAttrezzatura();
        	                executeSelectUtilizzo();
        	                dispose();
        	            } else {
        	                JOptionPane.showMessageDialog(Operazione5.this, "Errore durante l'inserimento dei dati.");
        	            }
        	        }
        	    } catch (SQLException ex) {
        	        ex.printStackTrace();
        	        JOptionPane.showMessageDialog(Operazione5.this, "Errore durante l'inserimento: " + ex.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
        	    } catch (NumberFormatException ex) {
        	        JOptionPane.showMessageDialog(Operazione5.this, "Il codice serie e la quantità devono essere numeri interi.", "Errore", JOptionPane.ERROR_MESSAGE);
        	    }
        	}
        });

        panel.add(insertButton);

        add(panel);
        setVisible(true);
    }

    // Metodo per eseguire la select e aggiornare l'outputArea in MenùOp
    private void executeSelectAttrezzatura() {
        String selectAttrezzaturaQuery = "SELECT * FROM attrezzatura";
        StringBuilder outputBuilder = new StringBuilder();
        outputBuilder.append("----- Attrezzatura -----\n");
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(selectAttrezzaturaQuery);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int codiceSerie = resultSet.getInt("codiceserie");
                String tipo = resultSet.getString("tipo");
                String stato = resultSet.getString("stato");
                int quantita = resultSet.getInt("quantità");
                String nome = resultSet.getString("nome");
                outputBuilder.append("Codice Serie: ").append(codiceSerie).append(", Tipo: ").append(tipo)
                        .append(", Stato: ").append(stato).append(", Quantità: ")
                        .append(quantita).append(", Nome: ").append(nome).append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Aggiorna l'outputArea di MenùOp
        menuOp.aggiornaOutputArea(outputBuilder.toString());
    }

    private void executeSelectUtilizzo() {
        String selectUtilizzoQuery = "SELECT * FROM utilizza";
        StringBuilder outputBuilder = new StringBuilder();
        outputBuilder.append("----- Utilizzo Attrezzatura -----\n");
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(selectUtilizzoQuery);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String usernameCliente = resultSet.getString("usernamecliente");
                int codiceSerieAttrezzatura = resultSet.getInt("codiceserieattrezzatura");
                outputBuilder.append("Username Cliente: ").append(usernameCliente)
                        .append(", Codice Serie Attrezzatura: ").append(codiceSerieAttrezzatura).append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Aggiorna l'outputArea di MenùOp con i dati recuperati dalla tabella 'utilizza'
        menuOp.aggiornaOutputArea(outputBuilder.toString());
        dispose();
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenùOp menuOp = new MenùOp();
            Operazione5 operazione5 = new Operazione5(menuOp);
            operazione5.setVisible(true);
        });
    }
}
