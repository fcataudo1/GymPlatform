module Connessione.java {
	requires java.sql;
	requires java.desktop;
	
}

